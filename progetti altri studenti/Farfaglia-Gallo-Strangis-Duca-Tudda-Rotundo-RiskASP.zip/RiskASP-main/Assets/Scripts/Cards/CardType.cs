namespace Cards
{
    public enum CardType
    {
        Infantry,
        Cavalry,
        Artillery,
        Wild
    }
}