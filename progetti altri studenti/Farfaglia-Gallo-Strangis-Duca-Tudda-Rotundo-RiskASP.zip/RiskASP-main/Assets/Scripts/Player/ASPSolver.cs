namespace player
{
    public enum ASPSolver
    {
        Clingo,
        DLV2
    }
}