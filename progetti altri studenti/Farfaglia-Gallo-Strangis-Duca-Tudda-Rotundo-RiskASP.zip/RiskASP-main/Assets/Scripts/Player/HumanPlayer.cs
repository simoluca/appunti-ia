using UnityEngine;

namespace player
{
    [RequireComponent(typeof(Player))]
    public class HumanPlayer : MonoBehaviour
    {
        
    }
}