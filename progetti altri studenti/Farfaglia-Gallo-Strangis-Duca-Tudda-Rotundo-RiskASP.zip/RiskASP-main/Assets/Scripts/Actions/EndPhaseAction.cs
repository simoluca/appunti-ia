using player;

namespace Actions
{
    public class EndPhaseAction : PlayerAction
    {
        public EndPhaseAction(Player player, int turn) : base(player, turn)
        {
        }
    }
}